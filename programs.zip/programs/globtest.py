

import glob

files = glob.glob(r"C:\Users\Rivatech\Desktop\programs\*.py")
print(files)


import subprocess

output = subprocess.getoutput("dir")
print(output)