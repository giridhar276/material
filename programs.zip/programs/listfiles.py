# from same directory
import os
for file in os.listdir():
    print(file)
# from C:\\
import os
for file in os.listdir("C:\\"):
    print(file)
# display files and directories seperately
filelist = []
dirlist = []
for file in os.listdir():
    if os.path.isfile(file):
        filelist.append(file)
    else:
        dirlist.append(file)
print(filelist)
print(dirlist)
# delete all .csv files
for file in os.listdir():
    if os.path.isfile(file) and file.endswith(".csv"):
        os.unlink(file)
# files and its size
for file in os.listdir():
    if os.path.isfile(file):
        getsize = os.path.getsize(file)
        print(file.ljust(20) , getsize )
        
