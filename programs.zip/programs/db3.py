#import pymysql
import csv
from configparser import ConfigParser
parser = ConfigParser()
parser.read('properties.conf')
username = parser.get('database_config', 'username')
password = parser.get('database_config', 'password')
hostname = parser.get('database_config', 'hostname')
port = parser.get('database_config', 'port')
database = parser.get('database_config','database')

try:
    with pymysql.connect(host =hostname,port=port,user=username ,password =password,database=database) as db:

        with open("realestate.csv","r") as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                query = "insert into realestate2 values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(*line)
                db.execute(query)
                print(db.rowcount , " record inserted")
 
except pymysql.IntegrityError as e :
    print(e)

except pymysql.ProgrammingError as e :
    print(e)
			
except pymysql.DataError as e :
    print(e)    
			
except pymysql.NotSupportedError as e :
    print(e)    
except pymysql.OperationalError as e :
except Exception as e :
