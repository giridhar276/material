

file = input("Enter any file :")
print("you entered :", file)