

# class definition
class  Student :
    def dislayName(self):
        print("this is displayName()")
        
    def displayEmpID(self):
        print("this is displayEmpID()")


# object
s1 = Student()

s1.dislayName()

s1.displayEmpID()

        
# class contains data members and member function

# object is instance of the class

# self is the instance of the object
