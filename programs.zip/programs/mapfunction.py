alist = [10,20,30,40]
#expected output : [15,25,35,45]

blist = []
for val in alist:
    blist.append(val + 5 )
print(blist)    

# map(functionname, iterable)
def increment(x):
    return x + 5
print(list(map(increment , alist)))

# using lambda with map
print(list(map(lambda x :x + 5 , alist)))

# converting list of strings ---> list of ints
values =['1','2','3','4']
print(list(map(lambda x :int(x) , values)))

# filtering the list
alist = list(range(1,100))
# display all odd numbers
print(list(filter(lambda x : x%2 , alist)))
# display all even numbers
print(list(filter(lambda x : x%2  == 0, alist)))
