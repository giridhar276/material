import os ,requests,json    

server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)
local_file = "githubtest0.py"
 
path = "C:\\Users\\Rivatech\\Desktop\\programs"
os.chdir(path)
for file in os.listdir(path):
    if os.path.isfile(file) and file.endswith(".py"):
        with open(file) as fobj:
            content = fobj.read()
            files = {
            "description": file + " testing",
            "public": "true",
            "user" : user,
            "files": {
            file: {
            "content": content
                }
              }
            }
            files["files"].update({file :{ "content":content}})
        r1 = requests.post(url, data=json.dumps(files), auth=(user,'6251892c3d18d227a8bbae493fe9459915ec5cd7'))
        print(r1.json())
