

import myfunctions


myfunctions.append()
myfunctions.extend()
myfunctions.clear()
