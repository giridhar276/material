# IP validation

ipstring = input("Enter any IP :")

ip = ipstring.split(".")

# converting list of strings ---> list of integers
ip = list(map(lambda x: int(x) , ip))

if ip[0] in range(1,256) and ip[1] in range(0,256) and ip[2] in range(0,256) and ip[3] in range(0,256):
    print("Valid IP")
else:
    print("Invalid IP")





flag = True
for item in ip:
    item = int(item)
    if item not in range(1,255):
        flag = False

if flag :
    print("Valid IP")
else:
    print("INvalid IP")
