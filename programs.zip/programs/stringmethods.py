 
# working with string methods
name = "python programming"
print(len(name))
print(name.capitalize())
print(name.upper())
print(name.count('p'))
print(name.count('prog'))
print(name.lower())
print(name.center(30))
print(name.center(30,"*"))
# converting to list
print(name.split(" ")) 
print(name.replace("python","scala"))

aname = "I love {} and {}"
print(aname.format("unix","oracle"))
print(aname.format(1,2))
print(aname.format("scala","spark"))

name = '  python '
# remove space at both the ends
print(name.strip())  
# remove space at left end
print(name.lstrip())

print(name.find('z'))  # will return -1
print(name.find('p'))  # will return the index of p
bname = "scala"
print(bname.startswith("p"))
print(bname.startswith("s"))
print(bname.endswith("z"))
print(bname.endswith("a"))
print(bname.isupper())
print(bname.islower())
print(bname.isalpha())
