

# defining all the methods
def append():
    print("this is append()")


def extend():
    print("this is extend()")

def clear():
    print("this is clear()")


def reverse():
    print("this is reverse()")


def sort():
    print("this is sort()")

# execute the below if you are code directly
if __name__ == "__main__":
    append()
    extend()
    clear()
    reverse()
    sort()
          
          
