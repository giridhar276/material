


class Student:
    # constructor
    def __init__(self,name = 0,roll = 0):
        self.name = name
        self.roll = roll

    def studentInfo(self):
        print("Student name :", self.name)
        print("Student roll :", self.roll)



s1 = Student()
s1.studentInfo()
        
