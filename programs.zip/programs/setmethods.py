
aset = {10,10,20,30,10,10,10}
print(aset)
bset  = {30,40,50}
print(aset.union(bset))
print(aset.intersection(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))
aset.add(10)
print("After adding :", aset)
aset.add(1000)
print("After adding :", aset)
print(aset.difference(bset))
# using symbols
print(aset & bset)  # intersection
print(aset | bset ) # union
print(aset - bset)  # difference
print(bset - aset)