import pymysql

with pymysql.connect(host ='localhost',port=3306,user='root' ,password ='india@123',database='jpmc') as db:

    print(db)  # will display the connection string
    # defining query
    query = "select * from realestate"
    # execute query
    db.execute(query)
    # display all the records
    # every record is a tuple
    for record in db.fetchall():
        print(record)

    # insert query
    query = "insert into realestate values('{}','{}')".format('110 Cross Road','Chennai')
    db.execute(query)

    print(db.row,count , " record inserted")
    

    query = "select * from realestate"
    # execute query
    db.execute(query)
    # display all the records
    # every record is a tuple
    for record in db.fetchall():
        print(record)
    


