'''
write a program to display the below information
1. current working directory
2. current user name
3. display the current python version
4. display all the list of libraries
'''


import os
import sys
print("Current working directory :", os.getcwd())
print("User name :", os.getlogin())

print("OS name :", os.name)

print("Current Python version :", sys.version)
print("Current python version :", sys.version_info)

print("Libraries :", sys.modules)
print(sys.platform)
