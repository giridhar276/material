
if 1 < 2 :
    raise TypeError("Invalid operation")
