# without context manager

import pymysql
db = pymysql.connect(host ='localhost',port=3306,user='root' ,password ='india@123',database='jpmc')

print(db)  # will display the connection string
cursor = db.cursor()
# defining query
query = "select * from realestate"
# execute query
cursor.execute(query)
# display all the records
# every record is a tuple
for record in cursor.fetchall():
    print(record)

db.close()    
