# unique cities using list
import csv


try:
    citylist  = list()

    filename = input("Enter any filename :")
    with open(filename ,"r") as fobj:
        # converting file object to csv object
        reader = csv.reader(fobj)
        print(reader)
     
        for line in reader:
            # each line will be the list
            citylist.append(line[1])
     

    for city in set(citylist):
        print(city)
                 
except FileNotFoundError :
    print("File not found")
