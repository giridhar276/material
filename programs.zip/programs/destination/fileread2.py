
# used to download the file 
import urllib.request


link =  "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"

# reading the filename from the link
filename = link.split("/")[-1]

urllib.request.urlretrieve(link )


with open(filename,"r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)

