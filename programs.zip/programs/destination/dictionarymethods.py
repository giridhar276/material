adict = {"chap1":10 ,"chap2":20 }
# adding new key-value pairs
adict["chap3"] = 30
adict["chap4"] = 40
adict["chap1"] = 1000
print("Dictionary :", adict)

print(adict.keys())  # ONLY keys
print(adict.values())# ONLY values
print(adict.items()) # in list format

#print(adict["chap5"]) # will throw error

print(adict.get("chap5"))#   None
print(adict.get("chap5","default"))

# adding key to the dictionary
adict.setdefault("chap6")
print(adict)
# adding key:value to dictionary
adict.setdefault("chap6",60)
print(adict)
adict.setdefault("chap6",600)
print(adict)
bdict = {"chap7":70 ,"chap8":80}
# combining 2 dictionaries
adict.update(bdict)
print("After updating :", adict)