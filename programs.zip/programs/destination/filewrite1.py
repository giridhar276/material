
# write operation - regular approach
fwrite = open("numbers.txt","w")
fwrite.write("python programming\n")
fwrite.write("scala programming\n")
fwrite.close()



# using context manager
# NOT required to close the file
with open("values.txt","w") as fw:
    fw.write("spark\n")
    fw.write("hadoop\n")
    