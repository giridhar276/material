
#with open("realestate.csv","r") as fobj:
#    for line in fobj:
#        # will remove white space at the end
#        line = line.strip()
#        output = line.split(",")
#        print(output)
#        
        
# using csv library
# all the unique cities using set
import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    print(reader)
 
    for line in reader:
        # each line will be the list
        cityset.add(line[1])
 

for city in cityset:
    print(city)        

        