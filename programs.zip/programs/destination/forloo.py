# for loop with range
end = 10
for val in range(1,end + 1):
    print(val)


# for with list
alist = ["unix","oracla","spark"]
for val in alist:
    print(val)

# for with tuple
atup = (10,20,"hadoop")
for val in atup:
    print(val)

# for with dictionary
book = {"chap1":10 ,"chap2":20 }
for key in book:
    print(key)           # key
    print(book[key])     # value


# for with set
aset = {10,10,10,10,10,10,20}
for val in aset:
    print(val)
    
