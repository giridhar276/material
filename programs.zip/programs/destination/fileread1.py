
# fobj can be called as file object or file variable
fobj = open("numbers.txt","r")

for line in fobj:
    # remove white space at the end of the string
    line = line.strip()
    print(line)

fobj.close()

#### using context manager
with open("numbers.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
        
        
        