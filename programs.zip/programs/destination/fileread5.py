
# display ONLY particular line
with open("realestate.csv") as fobj:
    # will read the complete file in list format
    data = fobj.readlines()
    print(data[3])
    
    
with open("realestate.csv", buffering = 1000) as fobj:
    # will read the complete file in list format
    data = fobj.readlines()
    print(data[3:15])    