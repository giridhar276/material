# unique cities using dictionary
import csv
citydict = dict()
with open("realestate.csv","r") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    print(reader)
 
    for line in reader:
        # each line will be the list
        citydict[line[1]] = 1 

for city in citydict.keys():
    print(city)
                 
