colors = [
{
"colors": "red",
"values": "#f00"
},
{
"colors": "yellow",
"values": "#ff0"
},
{
"colors": "black",
"values": "#000"
}
]

for  item in colors:
    color = item['colors']
    val = item['values']
    print(color.ljust(10),val)
