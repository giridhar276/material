
import requests
import json

url = "https://api.github.com"

response = requests.get(url, auth=('giridharpython','6251892c3d18d227a8bbae493fe9459915ec5cd7'))


data = json.loads(response.text)

for key,value in data.items() :
    print(key.ljust(20) , value)