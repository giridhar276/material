import os ,requests,json    
 
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)

files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files" : {}
}
path = "C:\\Users\\Rivatech\\Desktop\\programs"
os.chdir(path)
for file in os.listdir(path):
    if os.path.isfile(file) and file.endswith(".py"):
        with open(file) as fobj:
            content = fobj.read()
            files = {
            "description": file + " testing",
            "public": "true",
            "user" : user,
            "files": {
            file: {
            "content": content
                }
              }
            }
            files["files"].update({file :{ "content":content}})
        r1 = requests.post(url, data=json.dumps(files), auth= (user,'Nolimits1@'))
        print(r1.json())
