import time

# epoch time
print("Epoch time :", time.time())

# display string formatted time
print(time.strftime("%d %b %Y %H %M %S"))

#creating the logfile with today's timestamp
filename = time.strftime("%d_%b_%Y.xlsx")

print(filename)

with open(filename,"w") as fobj:
    fobj.write("python\n")

print(time.asctime(time.localtime(time.time())))


# displaying date and time with datetime library
import datetime
print(datetime.datetime.now())

print(datetime.date.today())
