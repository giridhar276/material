from flask import Flask, escape, request

app = Flask(__name__)

@app.route('/')
def hello():
    return "this is hello section"


@app.route('/customers')
def customers():
    return "this is customers  section"

@app.route('/employees')
def employees():
    return "this is employees section"

@app.route('/departments')
def departments():
    return "this is departments section"


app.run(debug = True)