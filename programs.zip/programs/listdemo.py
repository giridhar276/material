
# list
alist = [10,20,30,40]
print(alist)
alist[0] = "unix"
print("After modifying :", alist)

#tuple
atup = (10,20,30,40,50)
atup[0] = "scala"
print("After modifying :", atup)