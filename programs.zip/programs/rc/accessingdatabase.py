
import pymysql

db = pymysql.connect(host='localhost',port=3306,user='root',password='password')

print(db)

cursor = db.cursor()

query = "create database boa1"

cursor.execute(query)

db.close()

