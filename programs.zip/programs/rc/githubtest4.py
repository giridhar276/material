import requests
import json
r = requests.get('https://api.github.com/user', auth=('giridhar276','2934dfe9ab555681eef4b7e41e2fac313607eb75'))
print(r.status_code)


info = json.loads(r.text)
for key in info:
    print(key.ljust(20) , ":"  , info[key])
