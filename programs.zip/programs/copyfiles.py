'''
create two directories as below in the local directory

source     :   copy few files to this folder
destination:   -- empty --

write a program to copy all the files from source to destination
'''
import os
import shutil
source = "C:\\Users\\Rivatech\\Desktop\\programs\\source\\"
destination = "C:\\Users\\Rivatech\\Desktop\\programs\\destination\\"
os.chdir(source)
for file in os.listdir(source):
    if os.path.isfile(file):
        shutil.copy(file , destination)
        print(file , " copied to ",destination)


# without using os.chdir()
source = "C:\\Users\\Rivatech\\Desktop\\programs\\source\\"
destination = "C:\\Users\\Rivatech\\Desktop\\programs\\destination\\"

for file in os.listdir(source):
    if os.path.isfile(file):
        shutil.copy(source + file , destination)
        print(file , " copied to ",destination)
