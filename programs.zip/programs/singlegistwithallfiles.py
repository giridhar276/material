import os   
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)

files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files" : {}
}
for file in os.listdir():
    if os.path.isfile(file) and file.endswith("py"):
        with open(file,"r") as fobj:
            content = fobj.read()     
            files["files"].update({file :{ "content":content}})
r1 = requests.post(url, data=json.dumps(files), auth=(user,'Nolimits1@'))
print(r1)
print(r1.json())
