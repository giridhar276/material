
# class definition
class  Student :
    def dislayName(self,name):
        self.name = name
        print("Student name is :", self.name)
        
    def displayEmpID(self,sid):
        self.sid =sid
        print("ID is :", self.sid)

# object
s1 = Student()

s1.dislayName("Ram")

s1.displayEmpID(101)

        
# class contains data members and member function

# object is instance of the class

# self is the instance of the object
