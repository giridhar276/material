


print(__name__)   #__main__
