



a,b = 10,20

if (a < b) :
    print("Inside if")
    print("Still inside if")
    print(a)
else:
    print("Inside else")
    print(b)