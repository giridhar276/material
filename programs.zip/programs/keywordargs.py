# keyword args


def display(first,second):
    print(first,second)

display(second = 20,first = 10)
