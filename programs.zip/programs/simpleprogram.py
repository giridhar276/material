
print(10,20)
print("unix","spark")

name = "python programming"
#  string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:5])
print(name[2:10])
print(name[:])
print(name[::])
print(name[::2])
print(name[0:15:2])
print(name[1:15:2])
print(name[::3])
print(name[-1])   #g
print(name[-4:-1])
print(name[::-1])   # reverse
print(name[-5:2])