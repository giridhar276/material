
import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("^pyt?hon$", line):
            print(line)
        
