# unique cities using list
import csv
import sys
try:
    citylist  = list()

    filename = input("Enter any filename :")
    with open(filename ,"r") as fobj:
        # converting file object to csv object
        reader = csv.reader(fobj)
        print(reader)     
        for line in reader:
            # each line will be the list
            citylist.append(line[1])     

    for city in set(citylist):
        print(city)               
except TypeError as error :
    print("Invalid operation")
    print("System error :", error)
    print(sys.exc_info())   

except ValueError as error :
    print("INvalid input")
    print("System error :", error)
    print(sys.exc_info())
except FileNotFoundError as error :
    print("File not found")
    print("System error :", error)
    print(sys.exc_info())
except Exception as error:
    print("Unknown exception")
    print("System error :", error)    
    print(sys.exc_info())    
