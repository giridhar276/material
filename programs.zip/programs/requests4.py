import requests
import json
 

server = "https://api.github.com"
url = server + "/gists"
user = 'giridharpython'
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

local_file = "db1.py"

description  = local_file.split(".")[0]
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": description,
    "public": "true",
    "user" : user,
    "files": {
    local_file : {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(user,'6251892c3d18d227a8bbae493fe9459915ec5cd7'))
print(r1.json())
