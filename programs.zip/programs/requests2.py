import requests
import json
url = "https://api.github.com/" 
endpoint = "gists"

payload = {
  "description": "Hello World Examples",
  "public": True,
  "files": {
    "db1.py": {
      "content": "class HelloWorld\n   def initialize(name)\n      @name = name.capitalize\n   end\n   def sayHi\n      puts \"Hello !\"\n   end\nend\n\nhello = HelloWorld.new(\"World\")\nhello.sayHi"
    },
    "db2.py": {
      "content": "class HelloWorld:\n\n    def __init__(self, name):\n        self.name = name.capitalize()\n       \n    def sayHi(self):\n        print \"Hello \" + self.name + \"!\"\n\nhello = HelloWorld(\"world\")\nhello.sayHi()"
    },
    "db3.py": {
      "content": "Run `ruby hello_world.rb` to print Hello World"
    },
    "db4.py": {
      "content": "Run `python hello_world.py` to print Hello World"
    }
  }
}

response = requests.post(url + endpoint,data = payload , auth=('giridharpython','6251892c3d18d227a8bbae493fe9459915ec5cd7'))


print(response.text)
'''
data = json.loads(response.text)


for key,value in data.items() :
    print(key.ljust(20) , value)
'''