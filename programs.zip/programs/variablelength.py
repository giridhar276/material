#variable length args
# all the values are stored in tuple
def display(*data):
    for val in data:
        print(val)

display(10,20,30,40,50,560,60)


##  **obj is the dictionary
def displayData(**info):
    for key in info:
        print(key)
        print(info[key])

displayData(chap1 = 10 ,chap2 = 20)
