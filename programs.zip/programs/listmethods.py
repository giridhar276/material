#  list methods
alist = [10,20,30,40]

print(len(alist))

print(alist)
alist.append(1)
print("After appending :", alist)
alist.append(10)
alist.append(130)
alist.append(120)
print("After appending :", alist)
# adding multiple values
alist.extend([34,32,4,323,6])
print("After extending:", alist)
getcount = alist.count(10)
print("Count of 10 :", getcount)
print("Index of 20 is :", alist.index(20))
# insert(where to insert , what to insert)
alist.insert(1,5)
alist.insert(3,25)
print("After inserting :", alist)
alist.pop()  # will last value by default
print("After pop :", alist)
alist.pop(1) #  remove value at the INDEX 1
print("AFter pop :", alist)
alist.remove(10) # will remove 1st occurence of 10
print("AFter removing :",alist)
alist.reverse()
print("AFter reverse :", alist)
alist.sort()
print("After sorting :", alist)
