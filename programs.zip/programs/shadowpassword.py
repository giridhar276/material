import getpass
password = getpass.getpass("Enter any password :")
print(password)



import stdiomask
# default mask is * 
password = stdiomask.getpass("Enter any password :")
print(password)

import stdiomask
password = stdiomask.getpass("Enter any password :",mask='$')
print(password)