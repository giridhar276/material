
# using function
def add(x):
    return x + 5


total = add(10)
print(total)


# lambda : lambda is the replacement of single liner function
# inline function

# syntax:     functionname = lambda variables : expression
add = lambda x : x + 5
total = add(10)
print(total)


getupper = lambda x : x.upper()
print(getupper("python"))


getsum = lambda x,y:x +y
print(getsum(10,20))
