import sys
def readFile(filename):
    try:
        with open(filename,"r") as fobj:
            for line in fobj:
                print(line)
    except FileNotFoundError as err:
        print("file doesn't exist")
    except Exception as err:
        print("Uknown error")
        print(sys.exc_info())
def writeFile():
    try:
        name = input("Enter your name :")
        filename =input("Enter any file name to write the content :")
        with open(filename,"w") as fw:
            fw.write(name + "\n")
    except Exception as err:
        print("Uknown error")
        print(sys.exc_info())         
print("-------------------")
print("1. FILE READ")
print("2. FILE WRITE")

choice = int(input("Enter your choice ?"))
print("-------------------")
if choice == 1:
    filename = input("Enter any filename :")
    readFile(filename)

elif choice == 2:
    writeFile()

else:
    print("Unknown option")
