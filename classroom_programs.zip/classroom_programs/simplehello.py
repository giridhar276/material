print("python programming")

print(1,2,'unix')

first = "scala"
print("programming language is :" , first)

first,second = 10,20
print("Values are :", first,second)

#list
alist =[10,20,30]
print(alist[0])   # 10
# replacing value AT index 0
alist[0] = 100
print("After modifying :", alist)
##### tuple declaration ####
atup = (10,20,30,40,'java')
atup[0] = 100
print("After modifying :", atup)