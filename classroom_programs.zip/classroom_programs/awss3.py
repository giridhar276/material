import boto3
import os
bucketName = "giritest1"

######### uploading all the files from your
######### local directory to S3 bucket

s3 = boto3.client('s3')
# reading files from your current directory
for file in os.listdir(): 
    if os.path.isfile(file):
        print("Uploading :",file)
        s3.upload_file(file,bucketName,file)