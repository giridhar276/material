
# for loop with tuple
atup =('unix','java')
for val in atup:
    print(val)

# for loop with dictionary
# reading key from the dictionary
adict = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key in adict:
    print(key)
    print(adict[key])

# for loop with dictionary
# reading key,value at a time
for key,value in adict.items():
    print(key,value)


# for loop with set
aset = {10,10,10,10,20}
for val in aset:
    print(val)
