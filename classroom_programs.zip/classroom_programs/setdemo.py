aset = {10,10,10,10,20}
print(aset)   # 10 20
