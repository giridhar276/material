
import os

filecount = 0
dircount = 0
for file in os.listdir():
    if os.path.isfile(file):
        filecount = filecount + 1
    elif os.path.isdir(file):
        dircount = dircount + 1


print("total files       :", filecount)        
print("total directories :", dircount)