#2nd method
import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        citylist.append(line[1])
    for city in set(citylist):
        print(city.ljust(15) , str(citylist.count(city)).rjust(3) , "times".rjust(5))


#write a program to replace the lines containing SACRAMENTO with MUMBAI and
#write the output to backup.csv
with open("realestate.csv","r") as fr:
    with open("backup.csv","w") as fw:
        for line in fr:
            # will remove white spaces at both the ends
            line = line.strip()
            # replacing the lines containing SACRAMENTO with MUMBAI
            line = line.replace("SACRAMENTO","MUMBAI")
            fw.write(line + "\n")


########## using csv library
import csv
with open("realestate.csv","r") as fr:
    with open("backup1.csv","w") as fw:
        reader = csv.reader(fr)
        for line in reader:
            if line[1] == "SACRAMENTO":
                line[1] = "MUMBAI"
            #recoverting the list--> string since ONLY string has to be passed to write()
            string = ','.join(line)
            fw.write(string + "\n")
            
            
