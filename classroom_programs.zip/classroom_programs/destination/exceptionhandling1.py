import csv
import sys
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line) 
except FileNotFoundError as err:
    print("File doesn't exist")
    print("System error :", err)
    print(sys.exc_info())
