with open("C:\Users\Admin\Desktop\numbers.txt","w") as fw:
    for value in range(20,0,-1):
        fw.write(str(value) + "\n")
        
