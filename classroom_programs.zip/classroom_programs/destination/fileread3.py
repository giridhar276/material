#3
#- reading the file in string format

# fr acts like cursor or handler or pointer
with open("clients.txt","r") as fr:
    print(fr.read())
