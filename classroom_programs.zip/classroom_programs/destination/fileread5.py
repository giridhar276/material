### display all the lines of the file
import csv
with open("realestate.csv","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)       
### display all the lines of the file
import csv
with open("realestate.csv","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print("Street :",line[0])        
        print("Street :",line[1])        
        print("---------------")    
# METHOD1        
#write a program to display all the UNIQUE city names from the file        
cityset = set()
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        cityset.add(line[1])
    for city in cityset:
        print(city)
        
        