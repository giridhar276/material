import csv
import sys
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)

    val =1 + "hello"            
except TypeError as err:
    print("Invalid operation")
    print("System error :", err)
    print(sys.exc_info())
except ValueError as err:
    print("Invalid operation")
    print("System error :", err)
    print(sys.exc_info())
except (IndexError,KeyError) as err:
    print("Invalid operation")
    print("System error :", err)
    print(sys.exc_info())    
except FileNotFoundError as err:
    print("File doesn't exist")
    print("System error :", err)
    print(sys.exc_info())
except Exception as err:
    print("this is base class Exception")
    print("System error :", err)
    print(sys.exc_info())
