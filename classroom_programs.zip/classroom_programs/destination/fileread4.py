#4
#- reading using csv library

import csv

# fr acts like cursor or handler or pointer
with open("clients11111111.txt","r") as fr:
    #converting file object to csv object
    reader = csv.reader(fr)
    #reading from csv object
    for line in reader:
        print(line)
