import subprocess as sp
import time
import pyautogui
programName = "notepad.exe"

sp.Popen(programName)
time.sleep(1)
pyautogui.typewrite("Welcome to python programming!\n")
pyautogui.typewrite("----------------------------------\n")

string = """
There are two ways of installing third party libraries\n\n"
"1. Manual download and install\n2. pip tool or easy_install tool\n"
"All the third party libraries are available in\n\nwww.pypi.python.org\n"""
 

liststr = list(string)


for char in liststr:
    time.sleep(0.02)
    pyautogui.typewrite(char)

