
import pymysql

try:
    with pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='accenture') as db:
        print(db)
        query ="select * from cityguide"
        db.execute(query)
        for record in db.fetchall():
            print("Street :", record[0])
            print("City   :", record[1])
            print("------------------")
        # insert query
        query = "insert into cityguide values('{}' ,'{}')"
        db.execute(query.format('Karve Nagar','Pune'))
        print(db.rowcount ,"record inserted")
    
    
except pymysql.MySQLError as err:
    print("Error occured")
    print(err)

except pymysql.InterfaceError as err:
    print(err)    
    
except pymysql.DatabaseError as err:
    print(err)    