alist = [10,20,30,40,50]

alist.append(9)
print("After appending :", alist)
alist.append(34)
alist.append(900)
print("After appending :", alist)
# extend() is used to pass multiple values
alist.extend([34,32,5,6,4])
print("After extending :", alist)

getcount = alist.count(10)
print("10 is repeated for :" ,getcount , "time")
# insert(where to insert , what to insert)
alist.insert(0,50)
print("After inserting :", alist)
alist.pop()  # will remove the last value by default
print("After pop :", alist)
alist.pop(0) # will remove the value at INDEX 0
print("After pop :", alist)
alist.remove(30)  # 30 will be removed
print("After remove :", alist)
alist.sort()
print("After sort :", alist)
alist.reverse()
print("After reverse :", alist)