from openpyxl import Workbook
import time
import csv

wb = Workbook()
ws = wb.active
with open("realestate.csv","r") as fr:
    reader = csv.reader(fr)
    for line in reader:
        ws.append(line)
        
filename = time.strftime("%d%m%Y%H%M%S.xlsx")
wb.save(filename)