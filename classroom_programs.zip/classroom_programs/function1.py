# function

# function body
def display(first,second):
    getsum = first + second
    return getsum


# calling function
total = display(10,20)
print("Sum of the numbers :", total)

