adict = {"emp1":["raj",28] ,"emp2":["ram",34] ,"emp3":["rita",24]}


if "emp2" in adict:
    print("Emp2 exists")
else:
    print("Emp2 doesn't exist")    
    
    
    
'''
data = ["perl","unix","perl","scala","perl"]

write a program to count the no. of occurences of each item

perl 3
unix 1
scala 1
'''    
data = ["perl","unix","perl","scala","perl"]

for lang in set(data):
    print(lang.ljust(10), data.count(lang))




