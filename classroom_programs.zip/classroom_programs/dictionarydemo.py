data = {"menu": {
  "id": "file",
  "value": "File",
  "popup": {
    "menuitem": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
    ]
  }
}}
  
print(data['menu']['id'])
print(data['menu']['value'])
print(data['menu']['popup']['menuitem'][0])
print(data['menu']['popup']['menuitem'][1])
print(data['menu']['popup']['menuitem'][2])