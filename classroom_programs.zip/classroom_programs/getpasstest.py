# hiding the password while typing
import getpass  # builtin library
password = getpass.getpass("Enter any password:")
print("You entered :", password)



import stdiomask   # third party library
password = stdiomask.getpass("Enter any password:")
print("You entered :", password)



import stdiomask   # third party library
password = stdiomask.getpass("Enter any password:",mask='$')
print("You entered :", password)