#################### web scrapping ###########
import requests
from bs4 import BeautifulSoup

try:
    host = "https://www.google.com"
    response = requests.get(host)
    #response = requests.get(host, auth=(user,password))    
    if response.status_code == 200 :
        print("connection is successful")
        soup = BeautifulSoup(response.text, 'html.parser')
        for link in soup.find_all('a'):
            print(link.get('href'))
            print("-------------------")
    else:
        print("unsuccessful")    
    
except requests.ConnectTimeout as err:
    print(err)    
except requests.ProxyError as err:
    print(err)    
except requests.ConnectionError as err:
    print(err)    
except requests.HTTPError as err:
    print(err)
except Exception as err:
    print("unknown error",err)    

