## METHOD 3  using map()
alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment ,alist)))

### METHOD 4   USINg  map with lambda
# lambda is called as inline function
# lambda is the replacment of single liner function

alist = [10,20,30,40]
print(list(map(lambda x:x+5 , alist)))
#### syntax of lambda
#functionname = lambda variables : expression



### method 5   list comprehension
alist = [10,20,30,40]
#syntax [  expression  for loop    ]
blist = [ val + 5     for val in alist ]
print(blist)
