import re

with open("languages.txt","r") as fr:
    for line in fr:
        line = line.strip()
        if re.search("pyt{3}hon programming",line):
            print(line)
            
###### re.sub
lang = "I love python programming"
line = re.sub("python","ruby",lang)
print(line)

##### re.findall
line = "I love rain in spain"
output = re.findall("ai",line)
print(output)
print("Count of 'ai' in string :", len(output))
 
            