## for loop with range

for val in range(1,11):
    print(val)

# reverse order
for val in range(10,1,-1):
    print(val)
# even numbers
for val in range(2,10,2):
    print(val)
# odd numbers
for val in range(1,10,2):
    print(val)

# for loop with string
name = "python"
for char in name :
    print(char)

# for loop with list
alist =[10,20,30,40]
for val in alist:
    print(val)


    
