
### METHOD 1
alist = [10,20,30,40]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)    



########## using user defined function  #  METHOD2
alist = [10,20,30,40]
blist = []
def increment(x):
    return x + 5

for val in alist:
    blist.append(increment(val))
print(blist)    




    