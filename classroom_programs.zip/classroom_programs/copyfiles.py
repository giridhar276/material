######################## METHOD 1
import os
import shutil
source = "C:\\Users\\Admin\\Desktop\\programs\\source"
destination = "C:\\Users\\Admin\\Desktop\\programs\\destination"

for file in os.listdir(source):
    shutil.copy(file,destination)
    print(file,"copied to", destination)
    
    
####################### METHOD2  using glob    
import glob    
source = "C:\\Users\\Admin\\Desktop\\programs\\source\*"
destination = "C:\\Users\\Admin\\Desktop\\programs\\destination"
for file in glob.glob(source):
    shutil.copy(file,destination)