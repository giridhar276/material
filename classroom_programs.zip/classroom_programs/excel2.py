from openpyxl import Workbook
import time
wb = Workbook()

# grab the active worksheet
ws = wb.active

for val in range(1,11):
    ws.append([val])


filename = time.strftime("%d%m%Y%H%M%S.xlsx")
wb.save(filename)