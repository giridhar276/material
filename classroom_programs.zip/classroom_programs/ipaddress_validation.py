'''
write a program to validate the IP address

Enter any IP address : 192.168.0.1
Its valid IP
Enter any IP address : 1001.1.2.3
Invalid IP
'''

ip = input("Enter IP address :")
iplist = ip.split(".")

# map() will convert all the list elements --> integers
iplist = list(map(int,iplist))

if iplist[0] in range(1,256) and iplist[1] in range(0,256) and iplist[2] in range(0,256) and iplist[3] in range(0,256):
    print("Valid IP address")
else:
    print("Invalid IP address")    
