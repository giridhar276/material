import paramiko
	

with open("list_of_hosts.txt","r") as fr:
	for host in fr:
		host = host.strip()
		host,port,username,password = host.split(",")

		ssh = paramiko.SSHClient()	
		ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
		ssh.connect(hostname=host, port=port, username=username, password = password)

		stdin,stdout,stderr = ssh.exec_command("hostname -I")	
	
		for line in stdout.read().splitlines():
		    line = line.decode('utf-8')
		    print(line)

		ssh.close()
