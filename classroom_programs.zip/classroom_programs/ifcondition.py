a = 10
b = 20
if a < b :
    print("A is less than B")
else:
    print("B is less than B")
    
    
    
name= "python"
if name.islower():
    print("String is lower")
    print("Inside if")
else:
    print("String is upper")
    
if name.endswith("n") :
    print("String is ending with n")
    
    
    
    
    
    