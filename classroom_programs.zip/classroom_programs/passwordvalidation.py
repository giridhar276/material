'''
write a program to capture username and password from the keyboard and validate the password

condition1:  length of the password should be greater than  5
condition2:   length of the password should be less than 12
condition3:  atleast  one symbol ( @ or * or  $ ) should exist in the password
condition4:  whole password SHOULD not be in upper case
'''

user = input("Enter any username :")
password = input("Enter any password :")

if len(password) in range(5,12) and ('@' in password or '$' in password) and not password.isupper():
    print("Valid password")
else:
    print("Invalid password")    