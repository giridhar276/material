

# method1
import glob

for file in glob.glob("D:\\*.*"):
    print(file)
    
    
print("-----------------------")
#method2

import os    
for file in os.listdir("D:\\"):
    print(file)    