from flask import Flask, escape, request

app = Flask(__name__)

@app.route('/')
def hello():
    return "This is the home page"

@app.route('/clients')
def clients():
    return "This is clients page"

@app.route('/customers')
def customers():
    return "This is customers page"


app.run(debug = True)