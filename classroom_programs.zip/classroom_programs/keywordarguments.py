# keyword arguments

def display(second,first):
    print(first)
    print(second)


display(first = 10 ,second = 20)
