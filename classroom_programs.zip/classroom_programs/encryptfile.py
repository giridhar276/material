from cryptography.fernet import Fernet
import os
# creating key
key = Fernet.generate_key()
fobj = open("mykey.txt","wb")
fobj.write(key)
fobj.close()


input_file = 'mypassword.txt'
output_file = 'mypassword.encrypted'

with open(input_file, 'rb') as f:
    data = f.read()

fernet = Fernet(key)
encrypted = fernet.encrypt(data)

with open(output_file, 'wb') as f:
    f.write(encrypted)

# You can delete input_file if you want
    
os.unlink(input_file)    