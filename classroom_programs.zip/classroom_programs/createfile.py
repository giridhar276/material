

import time

filename = time.strftime("%d_%b_%Y.log")

with open(filename,"w") as fw:
    pass
    
