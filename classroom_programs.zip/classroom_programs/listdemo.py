
alist = [10,20,30,40,50,60,70,80,90,100]

print(alist)
print(alist[0:10])
print(alist[0:10:2])
print(alist[::-1])
print(alist[3:6])
