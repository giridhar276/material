

import os

for file in os.listdir("C:\\"):
    print(file)