

import subprocess

output = subprocess.getoutput("dir")

print(output)