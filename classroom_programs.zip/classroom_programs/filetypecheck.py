'''
write a progam to capture filename from the keyboard and display the type of the file
if the filename is ending with .py  .... display "Its python file"
if the filename is ending with .pl   .... display "Its perl file"
If the filename is ending with .c  ....... display "Its C lang file"
if the filename is ending with .json ...  display "Its json file"

Enter any filename :  info.py
Python file
'''

filename = input("Enter any filename :")

if filename.endswith(".py"):
    print("Python file")
elif filename.endswith(".pl"):
    print("perl file")
elif filename.endswith(".c") :
    print("C file")
elif filename.endswith(".json"):
    print("json file")
else:
    print("unknown file")    