###### creating the directory  ######
import os
for value in range(1,10):
    dirname = "dir" + str(value)
    os.mkdir(dirname)
    
###########    removing the directory ####
import os
for value in range(1,10):
    dirname = "dir" + str(value)
    os.rmdir(dirname)

############ using while loop 
count = 1
maxcount = 10
while count <=maxcount :
    dirname = "dir" + str(count)
    os.mkdir(dirname)
    count = count + 1
        