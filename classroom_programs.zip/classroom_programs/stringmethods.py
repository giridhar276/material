
name = "python programming"
print(len(name))  # 18

print(name.capitalize())
print(name.upper())
print(name.startswith("z")) # check whether the string is starting with Z
print(name.endswith("g"))

output = name.split(" ")
print("After split :", output)
print(name.count('p'))
print(name.count('z'))    # display the no. of occurences of Z
print(name.isupper())     # check whether is string is upper or not
print(name.islower())     # check whether is string is lower or not

aname = " python "
print(aname.strip())   # will remove the space at both the ends of String
# passing value dynamically
bname = "I love {} and {}"   # string template
print(bname.format("python","unix"))  # passing values to string template
print(bname.format(1,2))

print("unix","python")
print("unix".ljust(10),"python")

print(name.replace("python","ruby"))
print(name)
name = name.replace("python","ruby")
print("After assignment :", name)

