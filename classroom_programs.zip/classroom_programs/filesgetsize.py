'''
write a program to display all the files and its size as below

expected output
---------------
file1     10 bytes
file2     30 bytes
'''

import os

for file in os.listdir():
    getsize = os.path.getsize(file)
    print(file.ljust(25), getsize ,"bytes")
