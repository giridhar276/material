#################### web scrapping ###########
import requests
try:
    host = "https://www.google.com"
    response = requests.get(host)
    #response = requests.get(host, auth=(user,password))    
    if response.status_code == 200 :
        print("connection is successful")
        print(response.text)
    else:
        print("unsuccessful")    
    
except requests.ConnectTimeout as err:
    print(err)    
except requests.ProxyError as err:
    print(err)    
except requests.ConnectionError as err:
    print(err)    
except requests.HTTPError as err:
    print(err)
except Exception as err:
    print("unknown error",err)    

