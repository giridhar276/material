from cryptography.fernet import Fernet
import pymysql
from configparser import ConfigParser
import sys
parser = ConfigParser()

key = Fernet.generate_key()
fobj = open("mykey.txt","rb")
key = fobj.read()

fobj.close()
#print(key)

f = Fernet(key)

parser.read('properties.conf')
username = parser.get('database_config', 'username')
passname = parser.get('database_config', 'password')

passname = passname.encode()  # convreting to byte string
passname = f.decrypt(passname)# decrypting the byte string
passname = passname.decode('utf-8')# decoding to normal string

hostname = parser.get('database_config', 'hostname')
portno = parser.get('database_config', 'port')
portno= int(portno)
db = parser.get('database_config', 'database')

try:
    with pymysql.connect(host=hostname,port=portno,user=username,password=passname,database=db) as db:
        print(db)
        query ="select * from cityguide"
        db.execute(query)
        for record in db.fetchall():
            print("Street :", record[0])
            print("City   :", record[1])
            print("------------------")
        # insert query
        query = "insert into cityguide values('{}' ,'{}')"
        db.execute(query.format('Karve Nagar','Pune'))
        print(db.rowcount ,"record inserted")
    
    
except pymysql.MySQLError as err:
    print("Error occured")
    print(err)

except pymysql.InterfaceError as err:
    print(err)    
    
except pymysql.DatabaseError as err:
    print(err)    