# variable length arguments
# If any object is prefixed with * , it is tuple
# function definition
def display(*data):
    for val in data:
        print(val)
# calling function
display(10,20,30,404,'unix','perl','scala')
##############################################
# If any object is prefixed with **, it is dictionary
def display1(**info):
    for key,value in info.items():
        print(key,value)
display1(chap1=10,chap2=20)
