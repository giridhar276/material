

filename = input("Enter any filename :")
print("you entered :", filename)

