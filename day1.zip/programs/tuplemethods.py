

atup = (440,10,30,340)

print(atup.count(50))  # 0 

print(atup.index(10))


 