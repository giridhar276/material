

filename = input("Enter any filename :")

output = filename.split(".")

print("Filename :", output[0])
print("Extension:", output[1])