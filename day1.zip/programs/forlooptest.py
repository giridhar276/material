


alist = [30,43,53,44,3434343,5]
for val in alist:
    print(val)