
# convert string to list
name = "python java scala spark"
output = name.split(" ")
print(output)

#converting list -----> string
alist = ['python', 'java', 'scala', 'spark']

string= ",".join(alist)
print(string)
