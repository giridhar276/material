

#write a program to display all the files
#from local directory and its size as below
import os

try:
    for file in os.listdir():
        if os.path.isfile(file):
            getsize = os.path.getsize(file)
            print(file.ljust(30) , getsize , "bytes")

except Exception as err:
    print(err)
