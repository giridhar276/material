

import os
import time
try:
    for file in os.listdir():
        today_date = time.strftime("%d-%m-%Y_")
        if file.endswith("csv"):

            newfile = today_date + file
            
            os.rename(file,newfile)
            print(file , "----->" + newfile)
            
except Exception as err:
    print(err)            