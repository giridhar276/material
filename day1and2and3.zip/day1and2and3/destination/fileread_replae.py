
import csv
 

filename = "SalesJan2009.csv"
cityset = set()
with open(filename,"r") as fr , open("backup.csv","w") as fw:
    
    reader = csv.reader(fr)
    # processing the data
    for line in reader:
        if line[5] == "Basildon":
            line[5] = "Hyderabad"
        elif line[5] == "Astoria":
            line[5] = "Pune"
        elif line[5] == "London":
            line[5] = "Chennai"
        strline = ",".join(line)
        fw.write(strline + "\n")
        