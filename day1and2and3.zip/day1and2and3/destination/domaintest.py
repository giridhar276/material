alist = ["google","oracle","microsoft"]


for item in alist:
    domain = "http://www." + item + ".com"
    print(domain)
    
    
domains = ["google","www.unix","oracle.com"]
for item in domains:
    if not item.endswith(".com"):
        item = item + ".com"
    if not item.startswith("www."):
        item = "www." + item
    print(item)