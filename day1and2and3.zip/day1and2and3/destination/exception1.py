import sys
try:
    filename = input("Enter any filename :")
    fobj =  open(filename,"r")    
        
except FileNotFoundError as err:
    print("File not found")   
    print("system error :", err)     
    print(sys.exc_info())
except TypeError as err:
    print("Invalid operation")
    print("system error :", err)
    print(sys.exc_info())
except (ValueError,ZeroDivisionError)  as err:
    print("Invalid input")
    print("system error :", err)
    print(sys.exc_info())
except Exception as err:    # default exception 
    print("UNknown error")
    print("system error :", err)
    print(sys.exc_info())

else:    
        for line in fobj:
            print(line)
        try:
            output =  54 + "hello"
        except TypeError as err:
            print(err)
     
    
print("After try-except block")
