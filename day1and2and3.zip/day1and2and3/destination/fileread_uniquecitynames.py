#write a program to display all the UNIQUE city name from the file
import urllib.request
import csv
# URL to download
link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = link.split("/")[-1]
# download the file to the local directory
urllib.request.urlretrieve(link,filename)

cityset = set()
with open(filename,"r") as fobj:
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        cityset.add(line[1])
    # displaying the output
    for city in cityset:
        print(city)
        
        
        
        
    

        