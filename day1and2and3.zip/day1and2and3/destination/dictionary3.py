
colors = [
{
"colors": "red",
"values": "#f00"
},
{
"colors": "yellow",
"values": "#ff0"
},
{
"colors": "black",
"values": "#000"
}
]

for item in colors:
    # validating each item is dictionary OR not
    if isinstance(item,dict):
        info = list(item.values())
        print(info[0],info[1])
        