## from local directory
import os

try:
    for file in os.listdir():
        print(file)
except Exception as err:
    print(err)
    
    
################ from D:#####################
    
import os
path = "D:\\"
print("#############", path, "############")
try:
    for file in os.listdir(path):
        print(file)
except Exception as err:
    print(err)    