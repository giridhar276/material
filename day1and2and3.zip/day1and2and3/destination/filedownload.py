

import urllib.request
import csv
# URL to download
link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = link.split("/")[-1]
# download the file to the local directory
urllib.request.urlretrieve(link,filename)


with open(filename,"r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        print("Steet name :",line[0])
        print("Price      :", line[9])
        print("--------------")
        
        
        