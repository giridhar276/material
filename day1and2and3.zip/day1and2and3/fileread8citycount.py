#write a progrm to display all the UNIQUE city names and the count of each city from the file
import urllib.request
import csv
# URL to download
link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = link.split("/")[-1]
# download the file to the local directory
urllib.request.urlretrieve(link,filename)
citylist = []
with open(filename,"r") as fobj:
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        citylist.append(line[1])
    # displaying the output
    for city in set(citylist):
        print(city.ljust(15) ,"   ", citylist.count(city))
