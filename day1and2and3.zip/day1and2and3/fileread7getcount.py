

#write a program to display the count of Residential flats from the file

import urllib.request
import csv
# URL to download
link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = link.split("/")[-1]
# download the file to the local directory
urllib.request.urlretrieve(link,filename)

count = 0
with open(filename,"r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        if line[-5] == "Residential":
            count = count + 1

    print("Total Residential flats :", count)
            
