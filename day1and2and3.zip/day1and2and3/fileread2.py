## method2
## reading the file line by line using readlines()
with open("employees.txt","r") as fr:
    print(fr.readlines())


#['ram,28,30000\n', 'siva,29,40000\n', 'rita,25,20000\n', 'venakt,30,50000\n']
