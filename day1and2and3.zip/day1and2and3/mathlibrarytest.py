import os

os.unlink("realestate.csv")