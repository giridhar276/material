
import shutil
import os
source ="C:\\Users\\Administrator\\Desktop\\programs\\source"
destination = "C:\\Users\\Administrator\\Desktop\\programs\\destination"
os.chdir(source)
try:
    if os.path.isdir(source) and os.path.isdir(destination):
        for file in os.listdir():
            shutil.copy(file,destination)
            print(file ,"copied to ", destination)
    else:
        print("directories are not existing")
except Exception as err:
    print(err)        