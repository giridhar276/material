

password = input("Enter any password :")

if len(password) in list(range(5,13)) and ('$' in password or '@' in password )  and not password.isupper():
    print("Valid password")
else:
    print("Invalid password")