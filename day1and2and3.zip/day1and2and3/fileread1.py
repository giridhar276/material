
## reading the file line by line
with open("employees.txt","r") as fr:
    for line in fr:
        #remove white spaces at end
        line = line.strip()
        print(line)
    