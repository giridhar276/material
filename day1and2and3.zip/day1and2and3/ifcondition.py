

a,b = 10,20

if a < b:
    print("A is less than B")
else:
    print("B is less than A")