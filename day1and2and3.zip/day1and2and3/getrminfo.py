import winrm
s = winrm.Session('192.168.17.43', auth=('Administrator', ''))
r = s.run_cmd('ipconfig', ['/all'])
print(r.status_code)