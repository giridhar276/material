## method1
## reading the file line by line
with open("employees.txt","r",buffering=1000) as fr:
    for line in fr:
        #remove white spaces at end
        line = line.strip()
        print(line)
