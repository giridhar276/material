try:
    filename = input("Enter any filename :")
    
    with open(filename,"r") as fobj:
        for line in fobj:
            print(line)

    output = 4 + "hello"
            
except Exception as err:
    print("File not found")   
    print("system error :", err)     
  
print("After try-except block")
