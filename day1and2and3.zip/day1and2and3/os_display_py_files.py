#write a program to display all the .py files from the local directory
import os
try:
    for file in os.listdir():
        if file.endswith(".py"):
            print(file)
except Exception as err:
    print(err)        
    
#write a program to display all the files and directories seperately

dirlist = []
filelist = []

try:
    for file in os.listdir():
        if os.path.isfile(file):
            filelist.append(file)
        elif os.path.isdir(file):
            dirlist.append(file)
except Exception as err:
    print(err)
else:
    print("-------------- FILES-------------")
    for file in filelist:
        print(file)
    print("------------- DIRECTORIES-----------")
    for file in dirlist:
        print(file)        

    