#method3
## reading the file to the string
with open("employees.txt","r") as fr:
    print(fr.read())
