# method4
# using csv library

import csv

with open("employees.txt","r") as fr:
    #converting file object to csv object
    reader = csv.reader(fr)
    for line in reader:
        print(line)

'''
['ram', '28', '30000']
['siva', '29', '40000']
['rita', '25', '20000']
['venakt', '30', '50000']
