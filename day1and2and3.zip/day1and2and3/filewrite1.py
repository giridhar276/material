
## write operation
fw = open("employees.txt","w")

fw.write("ram,28,30000\n")
fw.write("siva,29,40000\n")

fw.close()