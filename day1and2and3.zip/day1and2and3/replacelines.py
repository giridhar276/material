import fileinput



macs = {
    '': '',
    '': ''
}

filename = "output.txt"
for line in fileinput.input(filename , inplace=True):
    line = line.strip()
    print(macs.get(line, line))