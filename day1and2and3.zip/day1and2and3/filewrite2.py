
#2nd approach


## write operation
## context manager
## The file will be closed automatically when
## it comes out of indentation

with open("numbers.txt","w") as fw:
    for val in range(1,10):
        fw.write(str(val) + "\n")


