


for val in range(0,2):
    ip = "192.168."
    value = ip + str(val)
    
    for num in range(1,11):
        ipaddress = value + '.' + str(num)
        print(ipaddress)
