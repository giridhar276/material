
# creating 100 directories
import os

for value in range(1,100):
    dirname = "dir" + str(value)
    os.rmdir(dirname)
    
    
# removing directories    