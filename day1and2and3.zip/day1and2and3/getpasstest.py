########### using builtin library ############
#import getpass
#
#password = getpass.getpass("Enter any password :")
#
#print("You entered :", password)




############# using third party library ##########
print(" ***** using third party library ********" )
import stdiomask
password = stdiomask.getpass("Enter any password :",mask='$')
print("You entered :", password)