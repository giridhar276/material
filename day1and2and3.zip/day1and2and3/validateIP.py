

ipaddr = input("Enter any ip address :")

iplist = ipaddr.split(".")
# map(function,list)
iplist = list(map(int,iplist))

if len(iplist) == 4:
    if iplist[0] in list(range(1,256)) and iplist[1] in list(range(1,256)) and iplist[2] in list(range(1,256)) and iplist[3] in list(range(1,256)):
        print("Valid IP")
    else:
        print("Inalid IP")
else:
    print("Invalid IP")