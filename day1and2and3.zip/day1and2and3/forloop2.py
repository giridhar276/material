# for loop with range()
for val in range(1,11):
    print(val)
    
    