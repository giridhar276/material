data = ["perl","unix","perl","scala","perl"]

for item in set(data):
    print(item,  data.count(item))