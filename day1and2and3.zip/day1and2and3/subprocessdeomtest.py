# subprocess is the library used to invoke system commands
import subprocess
import os


if os.name == "nt":   # for windows
    command ="dir"
elif os.name == "posix":  # for linux
    command = "ls"

output = subprocess.getoutput(command)

print(output)