
# for loop with set

aset = {10,10,10,10,10,10,10,20}
for val in aset:
    print(val)

### displaying all unique values from list
alist = [10,10,10,10,10,20,30,30,30,30]
uniquevalues = set(alist)
for val in uniquevalues:
    print(val)

### OR ###
alist = [10,10,10,10,10,20,30,30,30,30]
for val in set(alist):
    print(val)


# display values in reverser order
for val in range(10,0,-1):
    print(val)

# display even numbers
for val in range(2,20,2):
    print(val)
