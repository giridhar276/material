# for loop with range()
for val in range(1,11):
    print(val)

# for loop with list
alist = [10,20,30,40,50]
for val in alist:
    print(val)

# for loop with string
string = 'python'
for char in string:
    print(char)

# for loop with tuple
atup = ('unix','java','scala')
for item in atup:
    print(item)

# for loop with dictionary
book = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key in book.keys():
    print(key)

book = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key,value in book.items():
    print(key,value)
    
