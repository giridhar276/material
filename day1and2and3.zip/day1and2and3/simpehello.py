   `print(10,20)

print("hello","python")

aname = "python"
print("language is :", aname)
# list 
alist =[10,20,30,40]
print("list elements are :", alist)
# replacing the 1st index value of the list
alist[0] = 100
print("After replacing :", alist)

#tuple
atup = (1000,'unix','oracle','scala')
print("tuple elements are :", atup)
#atup[0] = 10
print("After replacing :", atup)

#dictionary of values
book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)
#
print(book["chap1"]) # 10
print(book["chap2"])

# dictionary of lists
bookdict = {"chap1":[10,'Mark','UK'] ,"chap2":[20,'Rita','US']  }
print(bookdict["chap1"])
print(bookdict["chap2"])











