
name = "python programming"
### string slicing
# string[start:stop:step]
print(name)
print(name[0]) 
print(name[1])
print(name[0:4])  #pyth
print(name[3:7])
print(name[3:])
print(name[:6])
print(name[3:6])
print(name[0:15])
print(name[0:15:2])
print(name[1:15:2])
print(name[:])
print(name[::])
print(name[-1])    #g
print(name[-2])
print(name[-4:-1]) #min
print(name[::-1])# reverse of the



 string