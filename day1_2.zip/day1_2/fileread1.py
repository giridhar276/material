#- reading line by line

# fr acts like cursor or handler or pointer
with open("clients.txt","r") as fr:
    for line in fr:
        # to remove the white space at both the ends
        line = line.strip()
        print(line)
    
