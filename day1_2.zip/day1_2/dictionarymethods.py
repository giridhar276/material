adict = {"chap1":10 ,"chap2":20}
# displaying all the items in dictionary
print(adict)
print(adict["chap1"])
print(adict["chap3"])
print(adict.get("chap3"))
# ONLY keys
print(adict.keys())
# ONLY values
print(adict.values())
# items   [(key,value) ,(key,value)]
print(adict.items())

bdict = {"chap3":30 ,"chap4":40}
adict.update(bdict)
print("After updating :", adict)

# remove key:value item
adict.pop("chap1")
print("After pop :", adict)
## remove random key:value pair
adict.popitem()
print("After popitem :", adict)