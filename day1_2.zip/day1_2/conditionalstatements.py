# simple if
name = "python"
if name.isupper():
    print("String is defined in upper")


#### if else block
name = "python"
if name.isupper():
    print("String is defined in upper")
else:
    print("String is defined in lower")


# if-elif-elif-elif... else
filename = input("Enter any filename :")
if filename.endswith(".py"):
    print("Python file")
elif filename.endswith(".pl"):
    print("Perl file")
elif filename.endswith(".sh"):
    print("Shell file")
else:
    print("Unknown file")

