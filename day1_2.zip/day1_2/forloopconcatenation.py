'''
alist = ["google","oracle","microsoft"]

write a program to
add "http://www"  at the beginning and  
add ".com" at tht end of the string
'''

#METHOD1
alist = ["google","oracle","microsoft"]
string = "http://www.{}.com"
for item in alist:
    print(string.format(item))
    
    
#method2
alist = ["google","oracle","microsoft"]
for item in alist:
    print("http://" + item + ".com")   
    
    
    
    