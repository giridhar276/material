######## set operations  ######
aset = {10,20,30,40,10,10,10,10}
bset = {60,40,50,60,}

print(aset | bset)         
#OR
print(aset.union(bset))

print(aset & bset)
print(aset.intersection(bset))

print(aset.issubset(bset))
print(aset.issuperset(bset))

print(aset.difference(bset))
#OR
print(aset - bset)

# adding 100 to the set
aset.add(100)
print("Ater adding :", aset)