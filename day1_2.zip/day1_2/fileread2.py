#2
#- reading the file in list format

# fr acts like cursor or handler or pointer
with open("clients.txt","r") as fr:
    print(fr.readlines())
