# 1st method
fw = open("clients.txt","w")

fw.write("python programming\n")
fw.write("scala programming\n")

fw.close()

############################################
#2nd method-    CONTEXT MANAGER
# It is NOT required to close the file
# File will be closed automically 
############################################
with open("clients.txt","w") as fw:
    fw.write("python programming\n")
    fw.write("scala programming\n")

