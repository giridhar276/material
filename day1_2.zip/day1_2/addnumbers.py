### input captures the string ONLY
first = input("Enter first number :")   
second = input("Enter second number :")  

# typecasting(converting from one object) to another
getsum = int(first) + int(second)

print("Sum of the numbers :", getsum)