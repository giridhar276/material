infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} }

print("state".ljust(10), "literacy rate")
print("-----------------------")
for key,value in infodoc.items():
    for skey,svalue in value.items():
        print(skey.ljust(10),svalue)
