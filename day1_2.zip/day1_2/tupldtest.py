

atup = (10,20,30)
#atup[0] = 'unix'
print(atup)


# convert tuple to list
alist = list(atup)
alist[0] = 'unix'
# reconverting back to tuple
atup = tuple(alist)
print("After modifying :", atup)