from cryptography.fernet import Fernet

# creating key
key = Fernet.generate_key()
print("Key :",key)
print()

password = "india@123"
# converting to byte script
message = password.encode()
 

f = Fernet(key)
encrypted = f.encrypt(message)
# encrypted password
print(encrypted)
print()

# decrypting from encrypted password
decrypted = f.decrypt(encrypted)
# converting to string
print(decrypted.decode('utf-8'))
