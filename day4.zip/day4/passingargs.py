from optparse import OptionParser

parser = OptionParser()
parser.add_option("--username", dest="username",help="define username")
parser.add_option("--password", dest="password",help="define password")

(options,args) = parser.parse_args()
username = options.username
password = options.password

print(username)
print(password)
